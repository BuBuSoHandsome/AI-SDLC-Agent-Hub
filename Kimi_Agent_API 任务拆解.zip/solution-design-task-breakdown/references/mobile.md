# Mobile Breakdown Guidelines

## 目标

把 Mobile 职责整理成 Journey、Page、交互或公共能力级 Work Items，并通过 Grill 确认 Workspace／Repo、Module 和 Target Component。不要按每个 UI 元素或代码函数拆任务。

## 1. 提取 Mobile 工作范围

按文档证据检查：

- Landing／Entrance、Lite Mode 和可见性；
- Segment、Address 等 Common Capability 复用；
- Page、Form、Prefill、Validation 和空值行为；
- Consent、Notes、静态文案和本地资源；
- Page State、Re-entry、数据保留或重置；
- Navigation、Overlay、Modal、Error Page；
- API 调用时机、重复点击和结果展示；
- PDF、拨号、Config、Footprint／Analytics；
- Mobile Release 和跨端兼容要求。

不要改变 Solution Design 已决定的 Mobile／API 职责。例如 Consent 明确由 Mobile 校验时，不要擅自增加 API Consent 任务。

## 2. 归并 Work Items

优先按用户可理解的能力归并：

- Entrance and Eligibility Orchestration；
- Form Page and Validation；
- Navigation and Update Journey；
- Error and Contact Support；
- Submission and Acknowledgement；
- Local Content and Configuration；
- Logging and Release Enablement。

一个表单中的 Amount、Preferred Time、Name、Mobile Number 通常属于同一 Form Work Item，不要逐字段拆任务。若某公共能力跨 Journey 复用且有独立 Owner，可单独列出。

## 3. 识别复用与 No Change

区分：

- 修改现有 Page／Component；
- 新增 DCL-specific Component；
- 仅调用现有 Common Capability；
- 仅增加 Config／Asset；
- 跳转现有 Journey，内部逻辑 Out of Scope；
- 完全无 Mobile 改动。

“使用现有能力”不自动等于需要修改该能力。

## 4. Mobile Grill 顺序

先给出当前理解，再逐项确认：

1. 入口改哪个 Workspace／Repo、Module 和 Landing Component？
2. 页面是 Enhance 现有 Loan Form，还是新增 DCL-specific Page／Component？
3. Segment／Address 等具体复用哪个 Common Capability，是否无需改动？
4. Error Page、Overlay、PDF Viewer、Dialer 等是否复用现有组件？
5. Config、KFS、文案和 Footprint 分别由哪个 Module／Owner 承接？
6. 哪些 Target Component 仍需 Mobile TL 确认？

不知道时记录 `TBD — Mobile TL Review`，不要编造 Component 名称。

## 5. 依赖与风险

记录而不越界展开：

- API Contract 和调用顺序依赖；
- Personal Particular 等现有 Journey 的外部依赖；
- BA／PO 文案、客服号码、PDF 等内容 Blocker；
- 旧版 App、发布顺序和本地资源版本风险；
- Logging 目标和保留期待确认事项。

B/E 改动不进入 Mobile Task List。

## 6. Mobile Work Item 应包含

- Related FP 和 User Journey；
- Workspace／Repo／Module／Page／Component 及确认状态；
- Enhance／New／Reuse Only／Config；
- 3～7 条整体 Change Scope；
- API／Content／Common Capability 依赖；
- Open Items、Out of Scope 和 Expected Outcome。

不要输出 UI 代码、类名、具体状态管理实现或逐条 Unit Test 任务。
