# Digital Service API Breakdown Guidelines

## 目标

把 Digital Service 职责归并为 Endpoint-level Work Items，确认 Workspace／Repo、PAPI、Endpoint 和 Enhance／New。不要输出详细 API Contract 或代码实现。

按以下主线执行：

1. 识别哪些 FP 需要 Digital Service 提供能力；
2. 判断相关能力能否合并到一个 Endpoint；
3. 对照 Architecture／Group Standard，决定 Enhance Existing 或 New Endpoint；
4. 评估兼容性、SLA、容量和下游影响；
5. 通过 Grill 确认 Workspace／Repo 和 Target Endpoint。

## 1. 建立 API Capability Map

对每个涉及 Digital Service 的 FP 提取：

- Caller 与触发时机；
- Business Purpose；
- Query／Command；
- 输入、输出和敏感数据的概念范围；
- 成功、失败、超时、副作用和重试语义；
- 下游 SAPI 及同步／异步关系；
- 明确的 Out of Scope。

只继承 Solution Design 已决定的 Digital Service 职责，不要把 Mobile Common Capability 或纯前端能力误移入 API。

## 2. 判断能力能否合并到一个 Endpoint

先问“是否同一次完整业务操作”，不要先看能否在 24 秒内完成。

### 2.1 核心判断维度

- 调用主体是否一致；
- 调用时机是否一致；
- 业务目的是否一致，能否共同完成一个完整动作；
- Query／Command、读／写语义是否一致；
- 成功、失败和部分完成语义是否一致；
- 副作用、幂等和重试是否一致；
- 数据一致性、敏感级别和最小必要范围是否一致；
- Request／Response 是否自然内聚；
- 是否独立变化和发布。

### 2.2 倾向合并的信号

- 同一调用方执行同一个业务动作；
- 各能力总是需要一起执行；
- 可以作为一个整体安全重试；
- 成功与失败语义一致；
- 数据安全范围一致；
- 能力通常一起变化和发布。

### 2.3 倾向拆分的信号

- Query 与 Submit／Command 混合；
- 调用时机不同；
- 需要独立重试；
- 成功、失败或部分完成语义不同；
- 需要独立变化、发布或故障隔离；
- 数据安全级别或敏感性要求不同；
- 需要大量 `mode/action` 分支才能区分行为；
- 合并只是为了减少 URL 或请求数量。

多个内部 SAPI 调用可以属于一个 Submission Endpoint；不要把每个 SAPI 暴露成一个 PAPI Endpoint。

## 3. 分开判断三层复用

分别记录：

1. 复用 B/E SAPI；
2. 复用 PAPI／微服务；
3. 复用现有 Endpoint。

复用 SAPI 不证明应复用 Endpoint；New Endpoint 不自动意味着 New Microservice。不得因同属一个 Domain 就直接 Enhance。

## 4. 对照标准决定 Enhance 或 New

### 4.1 默认复用

遵循当前 Architecture Standard／Group Standard，优先调查 Existing Endpoint。组织要求参考 AMH 或指定标准实现时，先核对其既有模式和可复用资产；只有确认无法合理实现时，才提出 New Endpoint。

Group Standard 不是免于技术判断的理由。若需偏离标准，准备具体理由、风险和业务影响，并取得要求的 Architecture／Business Approval。

能在 Solution Design 阶段确定的架构约束和复用方向应尽量前置（shift left）；但不要求 Solution Design 预先写明具体 Workspace 或 Endpoint，缺失信息通过 Asset Investigation 和 Grill 补齐。

### 4.2 Enhance Existing Endpoint 检查清单

只有现有 Endpoint 已代表同一个业务操作时才优先 Enhance。调查：

- Workspace、Repo、PAPI、URL、Method 和 Owner；
- 当前用途是否与新能力属于同一个业务操作；
- 当前 Request／Response、Logic Flow 和下游调用链；
- 现有消费者及旧版本调用方；
- 新旧 Contract 的向后兼容性，包括必填字段、默认值、空值、枚举和错误码；
- 是否影响原有 Function／Flow，或增加额外 SAPI Call 和敏感数据；
- 是否需要大量 Journey-specific 分支；
- 回归、发布和回退风险。

空参数为兼容旧消费者而走原 Flow 可以合理；非法参数静默走原 Flow 需单独挑战，避免隐藏调用错误。不要在 Breakdown 中决定具体序列化或代码分支方式。

### 4.3 New Endpoint 检查清单

New Endpoint 需要说明继续 Enhance 的实际风险或成本高于新建及审批成本，并记录：

- Architecture Review／Architecture Board Approval；
- Endpoint／Service Registration 及组织要求的治理动作；
- API Owner、发布依赖和后续维护责任。

可准备的证据：

- 业务成功、失败或副作用语义不同；
- Contract 无法合理兼容，空值或校验规则冲突；
- 真正可复用的内部逻辑很少；
- 对现有消费者造成明显回归或发布风险；
- 实测性能、故障隔离或安全边界无法满足要求；
- Enhance 与 New 的总成本及风险对比。

“Request／Response 字段不同”只是信号，应进一步说明兼容风险，不要只以字段数量作结论。

## 5. 重新评估 SLA、容量和下游影响

Enhance 后不能只沿用原 Endpoint 的 SLA 结论，也不要求在 Breakdown 阶段证明绝对不会超时。

### 5.1 Latency／SLA

- 获取 Production Baseline、Average、P95／P99 和当前调用链；
- 评估新增同步 SAPI、处理和 Gateway／Network 开销；
- 区分串行与并行，复用现有调用时避免重复扣减耗时；
- 检查端到端耗时是否满足 Gateway 限制（例如 24 秒）及业务要求，并保留合理余量；
- 将实测、Timeout 配置和详细优化列为后续验证事项。

### 5.2 Capacity 和 Downstream Impact

- 区分 Mobile→PAPI 请求增加与 PAPI→SAPI 调用增加；
- 评估现有 Endpoint 调用量增长和单次调用内部工作量增长；
- 标记 Pod、Thread／Connection Pool、下游 SAPI Quota 等潜在风险；
- TL 判断存在实际容量风险后，再新增容量配置 Work Item；
- 不在 Breakdown 中直接计算 Pod 数量或详细 Pool 参数。

### 5.3 Security

检查脱敏、完整手机号等敏感数据是否只向必要调用方暴露，是否改变日志、权限或审计要求。

## 6. API Grill 顺序

逐个 Capability 询问，每次一个问题：

1. 是否已有类似业务能力，例如 Long Form 可支撑 Short Form？
2. 该能力在哪个 Workspace／Repo／PAPI？
3. 具体现有 Endpoint 是什么，当前做什么？
4. 两者是否同一业务操作，确定 Enhance 还是 New？
5. 是否符合 Group Standard／AMH，是否需要偏离审批？
6. 现有消费者和原 Flow 影响由谁确认？
7. SLA、容量和下游影响需要哪些 Production 数据或 Owner 验证？
8. New Endpoint 是否需要 Architecture Review 和 Registration？

不知道时记录 `TBD — API TL Review`，不要虚构资产或停止全部工作。

## 7. Endpoint Work Item 应包含

- Related FP、Business Purpose、Caller & Trigger；
- Enhance／New／Reuse Only／Investigation；
- Workspace／Repo／PAPI／Endpoint 及确认状态；
- 3～7 条整体 Change Scope；
- 下游 SAPI 依赖及 Digital 侧编排范围；
- Contract／Consumer Impact；
- Architecture Approval／Registration（如适用）；
- SLA、Capacity、Security Risk 和待验证事项；
- Open Items、Out of Scope 和 Expected Outcome。

不要拆成“生成编号、加日志、写字段映射、写 Unit Test”等独立任务。
