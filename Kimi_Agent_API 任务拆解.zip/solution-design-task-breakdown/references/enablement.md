# Third-party and Delivery Enablement Guidelines

## 目标

识别 Component Design 表之外的交付前提，整理第三方、网络、安全、平台和发布 Enablement。只生成有证据或合理推断且标记清楚的工作，不为 B/E 内部改动拆任务。

## 1. 全文扫描触发信号

检查 Component Interaction、Dependencies、Timeout Assessment、Open Items、Out of Scope 及正文中的：

- `third-party`、`vendor`、`external service`；
- `whitelist`、`firewall`、`proxy`、`DNS`、`network route`；
- `certificate`、`mTLS`、`secret`、`credential`；
- `security review`、`privacy`、`PII`、`approval`；
- `configuration`、`feature flag`、`deployment`、`release`；
- `sandbox`、`test account`、`content`、`migration`；
- `monitoring`、`alert`、`runbook`、`support`。

Component 表没有出现 Network 或 Security，不代表无需 Enablement。

## 2. 第三方服务检查

逐项判断 `Already Available／Required／Potentially Required／Not Applicable`：

- Vendor Onboarding、采购或风险评估；
- API Integration 和 Sandbox；
- Whitelist、Firewall、Proxy、DNS；
- Certificate、mTLS、Credential 和 Secret；
- 测试账号、测试数据和联调窗口；
- PII、Privacy 和 Security Review；
- Quota、Rate Limit 和容量依赖；
- Monitoring、Alert、Vendor Support 和 Escalation。

已有成熟接入时标记 Reuse Only，不重复生成开通任务。从“调用第三方”推导白名单检查时，标为 Proposed Enablement 或 Investigation，不伪称 SD 已明确要求。

## 3. 网络、安全与 Release Notes

若白名单、证书或审批不妨碍开发启动、只影响上线，最终只在 Release Notes 写一句简短提醒，例如：

`- FP-XXX：上线前确认第三方 PROD Whitelist 已开通。`

内部可检查调用方、目标服务、环境、域名／IP、Port、Protocol、Source NAT／Egress、Owner 和 lead time，但不要输出网络参数表，也不要展开防火墙命令或实施步骤。

若确实需要修改 Digital 代码、配置或内容，才进入 Task List，并按实际 Workspace／Location 和 Target Asset 描述。

## 4. Platform、Content 和 Release

按文档证据识别：

- Config／Feature Flag／Secret 配置；
- 环境准备、测试数据和发布顺序；
- 内容初始化、数据 Migration、文案和 PDF；
- Monitoring、Alert、Runbook、Rollback 和 Support Handover；
- Architecture、BA／PO、Compliance 等审批。

TL 确认存在容量风险后，才生成 Pod、Connection Pool 或 Quota 修改 Work Item；不要提前给出具体数值。

## 5. Enablement Grill 顺序

1. 第三方或平台能力是否已有成熟接入可复用？
2. 具体 Vendor、Service、Network Path 和 Environment 是什么？
3. 哪些 Enablement 已存在，哪些需要新增？
4. 申请 Owner、审批周期和 Release Blocker 是什么？
5. 哪些参数仍需 Network／Security／Vendor Owner 确认？

不知道时记录 `TBD — 对应 Owner Review`，继续其他 Work Item。

## 6. B/E 边界

B/E SAPI 只做内部依赖分析；在相关 API Task 的改动描述中写明用途以及复用现有 Call 或评估 New Call。即使 SAPI 可能需要改动，也不生成 B/E 设计、开发任务或独立依赖表。
