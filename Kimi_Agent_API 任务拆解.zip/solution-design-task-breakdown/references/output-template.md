# Task Breakdown Output Template

最终输出严格只保留 `Task List` 和 `Release Notes` 两部分，不使用表格。Coverage Matrix、Decision Log、Risk Register 和 Dependency Register 仅用于内部分析，不要输出。

# [Requirement／Journey] Task Breakdown

## 1. Task List

按实际 Component 分节。API by Endpoint；Mobile、AEM 和其他内容／配置平台 by Page／Component／Content Asset。一个 Task 可关联多个 FP，不要按 FP 重复拆分同一个 Target Asset。

### [Task 名称]

Component：［Mobile／AEM／Digital Service API／实际内容或配置平台］  
Workspace／Location：［代码 Workspace／Repo，或非代码管理位置；未知写 TBD］  
Target Asset：［Endpoint／Page／Component／Content Asset；未知写 TBD］  
Change Type：［Enhance／New］  
Related FP：［FP-XXX、FP-XXX］

改动内容：
- ［整体业务、页面或内容改动。］
- ［关键校验、处理或集成。］
- ［API Task 写明相关 SAPI 是复用现有 Call 还是评估 New Call。］

规则：

- 每个 Task 只保留上述字段和分点描述，不添加 Business Purpose、Risk、Owner、Expected Outcome 等额外字段。
- 改动描述写到业务处理、关键校验、SAPI 调用和主要结果，不写 Class、注解、方法或详细代码。
- Grill 后仍无法确认 Workspace／Location 或 Target Asset 时，在该字段标 `TBD`，继续下一项。
- 纯内容或配置工作使用实际 Location，不强行填写代码 Workspace。
- Component 使用实际交付载体；只有载体未知时才使用 `F/E Content／Configuration（TBD）`。

## 2. Release Notes

只用简短 Bullet 记录不阻塞开发启动、但可能影响上线的事项：

- ［Related FP／Task］上线前确认第三方 PROD Whitelist 已开通。
- ［Related FP／Task］上线前完成所需审批、证书、配置或发布准备。

不要在这里展开网络参数、Owner 矩阵或详细实施步骤，也不要把需要实际修改代码／内容的工作移到 Release Notes。

## 内部自检

- 每个 FP 均已映射到 Task、No Change 或 Out of Scope，但无需输出映射表。
- 同一 Endpoint／Component 未按 FP 重复拆 Task。
- B/E SAPI 只出现在 API 改动描述中，未生成 B/E Task 或独立依赖表。
- 所有 Workspace／Location 和 Target Asset 均已确认或标 TBD。
- 第三方、Whitelist、审批等上线提醒未遗漏。
- 输出只有 Task List 和 Release Notes，且没有表格。
