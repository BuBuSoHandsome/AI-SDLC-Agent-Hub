# AEM Breakdown Guidelines

## 目标

将 AEM 职责整理成 Component、Template、Content 或 Publishing 能力级 Work Items，并确认实际 Workspace／Repo／Site 和 Target Asset。Solution Design 明确 AEM 为 `none` 时输出 No Change，不要生成 Grill 或任务。

## 1. 提取 AEM 工作范围

按证据检查：

- Site、Section、Page 和 Template；
- AEM Component、Dialog 和 Content Model；
- Content Fragment、Experience Fragment、DAM Asset；
- Authoring、Workflow、Review 和 Approval；
- Publish／Replication、Cache 和 Release；
- 文案、PDF、链接和多语言内容；
- Mobile／API 对 AEM 内容的依赖。

区分代码改动、内容改动和纯发布工作，不要把所有 AEM 工作都写成 Component Development。

## 2. 归并 Work Items

优先按以下能力归并：

- Enhance／New AEM Component；
- Template／Dialog／Content Model Change；
- Content／Asset Preparation；
- Workflow and Publishing；
- Content Dependency and Release Enablement。

同一 Component 的字段、Dialog 选项和样式通常属于一个 Work Item，不要逐属性拆任务。

## 3. AEM Grill 顺序

1. 改动位于哪个 Workspace／Repo、Site 和 Section？
2. 是 Enhance 现有 Component，还是 New Component？
3. 是否涉及 Template、Dialog 或 Content Model？
4. 内容位于 Page、Content Fragment 还是 DAM Asset？
5. 是否只需 Authoring／Publishing，不需要代码改动？
6. Author／Publish、Workflow、Cache 和 Release Owner 是谁？

不知道时记录 `TBD — AEM Owner Review`，不要猜测 Component Path。

## 4. 依赖与边界

- 记录 BA／PO 文案、KFS、翻译和合规审批依赖；
- 记录 Mobile／API 的内容消费方式，但不要重新设计其内部逻辑；
- 记录内容版本和发布顺序风险；
- 不为 B/E 内容处理或内部实现生成任务；
- 不进入 AEM Java 类、Sling Model 或具体代码设计。

## 5. AEM Work Item 应包含

- Related FP 和 Content／Page Purpose；
- Workspace／Repo／Site／Template／Component／Asset Path 及状态；
- Enhance／New／Content Only／Publish Only／No Change；
- 整体 Change Scope；
- Authoring、Approval、Publishing 和消费者依赖；
- Open Items、Out of Scope 和 Expected Outcome。
