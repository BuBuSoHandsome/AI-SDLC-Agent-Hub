---
name: solution-design-task-breakdown
description: 将 Solution Design Report 拆成 Digital 交付侧的 Component／Workstream-level Work Items，并通过逐个 Grill 确认实际 Workspace、Repo、Endpoint、Mobile Component、AEM Component 及 Enablement Owner。覆盖 Mobile、AEM、Digital Service API、第三方服务、网络、安全、平台与发布准备；记录 B/E 依赖但不拆 B/E 内部任务。当用户要求根据方案设计 breakdown task／task list、分配各 Component 改动、确认 enhance existing 或 new endpoint、评审已有 breakdown，或把需求方案转成可评审的实施工作时使用。不用于详细 Technical Design 或开发任务卡拆分。
---

# Solution Design Task Breakdown

## 目标

继承 Solution Design 的业务决策，将 Function Points、外部依赖和交付约束整理成可评审的 Work Items。通过 Grill 确认“做什么、在哪个 Workspace、对哪个资产做、整体改什么”，不要重新设计业务方案或进入代码级实现。

默认输出 Markdown；用户要求文件时再生成文件。

## 范围

### In scope

按文档证据动态选择 Mobile、AEM、Digital Service API、Third-party、Network、Security、Platform、Content、Release 等 Workstream。只生成有依据的工作，不为补齐模板虚构任务。

### Out of scope

- 不拆 B/E 内部设计、开发、配置或部署任务；B/E SAPI 只做内部分析，并在相关 API Task 的改动描述中写明复用或 New Call。
- 不输出类设计、JSON 序列化、方法命名、详细代码结构等 Technical Design。
- 不默认拆字段映射、日志、Unit Test 等开发任务卡。
- 不编造 Workspace、Repo、Endpoint、Component、Owner、消费者或 Production 数据。

Digital Service 调用 SAPI 属于 PAPI 集成范围；修改 SAPI 内部实现不属于本 Skill。

## 按需读取规则

开始对应工作前读取相关文件，不要一次加载所有 references：

- Digital Service API：[references/digital-service-api.md](references/digital-service-api.md)
- Mobile：[references/mobile.md](references/mobile.md)
- AEM：[references/aem.md](references/aem.md)
- 第三方、网络、安全、平台或发布 Enablement：[references/enablement.md](references/enablement.md)
- 最终报告与 Work Item 格式：[references/output-template.md](references/output-template.md)

评审已有 Breakdown 时，只读取涉及的 Component 规则，并使用 Grill 逐项挑战遗漏和无依据结论。

## 信息状态

始终区分：

- `Confirmed by SD`：Solution Design 明确说明。
- `Confirmed by Asset Investigation`：代码、API Catalogue 或资料调查确认。
- `Confirmed by User`：用户在 Grill 中确认。
- `Proposed`：待 Owner 评审的建议。
- `Assumption`：为继续工作而保留的假设。
- `TBD`：尚待调查，不等于 Solution Design Blocker。
- `Open Item`：需要指定角色决策。

不要把推断写成文档事实。未知 Repo、Endpoint、详细契约或 Production 数据不妨碍先出 Draft Breakdown。

## 工作流程

### 1. 建立 Breakdown Basis

读取整份 Solution Design，包括 Component Interaction、Component Design、B/E Dependencies、Timeout Assessment、Open Items 和 Out of Scope。提取：

- 文档版本、Requirement Source 和 FP 清单；
- 各 Component 职责、业务规则及成功／失败语义；
- 外部依赖、非功能约束和发布前提；
- 已确认决策、Implementation Investigation、Technical Design Item 和 Open Decision。

只有缺少关键业务决策、必须替方案重新做决定时，才标记 `SD Gap`。Endpoint 或 Workspace 未知不属于 SD Gap。

### 2. 建立 Coverage 与 Dependency Inventory

为每个 FP 给出 `Work Item／No Change／Out of Scope` 的处理结果。为每个外部依赖给出 `Reuse／Integration／Enablement／Investigation／External Dependency Only` 的处理结果。

同时扫描第三方、Whitelist、证书、Secret、配置、内容和发布要求；Component 表未出现不代表交付时不需要做。

### 3. 按 Capability 归并 Draft Work Items

不要机械地执行“一个 FP＝一个任务”或“一个 FP＝一个 Endpoint”。根据 Component 规则归并能力，保留 FP 可追溯性。

默认粒度：

- API：一个 Endpoint-level Work Item；
- Mobile：一个 Journey、Page、交互或公共能力级 Work Item；
- AEM：一个 Component、Template、Content 或 Publishing 能力级 Work Item；
- Enablement：需要实际交付改动时按 Target Asset 归并；只影响上线的提醒归入 Release Notes。

### 4. 读取 Component Guidelines 并补全 Draft

读取实际涉及的 references，补充 Target Asset 候选、Change Type、Change Scope、依赖、风险、假设和 Out of Scope。

没有资产证据时使用 `Proposed` 或 `TBD`，不要写成 Confirmed。

### 5. Grill 并确认 Target Assets

先展示当前理解和候选，再一次只问一个最关键的问题。按 Work Item 收敛，不要一次抛出整份问卷。

Grill 只解决：

1. 是否存在可复用的现有能力；
2. 能力位于哪个 Workspace／Repo；
3. 具体改哪个 Endpoint、Module、Page、Component、Template 或 Content Asset；
4. Enhance Existing 还是 New；
5. 现有 Flow／消费者、Owner 和审批依赖；
6. 是否需要第三方或平台 Enablement。

不要 Grill Solution Design 已明确的业务规则，也不要追问 JSON 注解、类设计、方法名、Pod 数量等后续实现细节。

推荐问法：

> 目前该 Work Item 需要［能力］。我理解可复用［候选能力］，位于［Workspace，如已知］。请确认实际 Target Asset，以及本次是 Enhance Existing 还是 New。

若用户回答不知道，记录 `TBD — Owner Review`、建议 Owner 和调查事项，然后继续下一个 Work Item；不要卡住整个 Breakdown。

Grill 后更新资产状态：

- `Confirmed`：目标资产及改动方式已确认；
- `Proposed`：有候选但待 Owner 确认；
- `TBD — Owner Review`：需要 TL／Owner 定位；
- `New — Approval Required`：需要新建及治理审批；
- `No Change`：复用现有资产，无需修改。

记录确认来源：`Solution Design／User Confirmation／Repo Inspection／API Catalogue／Owner Review`。

### 6. 内部收口风险、依赖和决策

在内部完成 Coverage Matrix、Decision Log、Risk 和 Dependency 分析，不要将这些分析表输出给用户。

不要为 B/E 依赖生成 B/E Work Item。API Task 需要集成 SAPI 时，直接在改动内容中写明复用现有 Call 或评估 New Call。若现有 SAPI 可能需要改动，只作为内部风险或 Grill 线索，不展开 B/E 工作。

需要实际修改代码、内容或配置的工作进入 Task List；不影响开发启动但影响上线的白名单、审批、证书和发布前提进入 Release Notes。

### 7. 输出并自检

读取输出模板，最终严格只输出 `Task List` 和 `Release Notes`，不使用表格。确保：

- 每个 FP、外部依赖和关键约束均在内部得到处理；
- API by Endpoint，Mobile／AEM／内容平台 by Target Asset，一个 Task 可关联多个 FP；
- 每个 Task 只包含 Component、Workspace／Location、Target Asset、Change Type、Related FP 和分点改动内容；
- 未确认的 Workspace／Location 或 Target Asset 直接标 TBD，并继续下一项；
- 未生成 B/E 内部任务、独立分析表或 Technical Design 细节；
- Enhance Existing 已考虑现有 Flow／消费者；
- 第三方和上线提醒已归入 Release Notes。

若用户要求交互式 Grill，先输出简短 Draft Summary，再逐问推进；全部关键问题关闭或标记 TBD 后，才输出 Final Breakdown。
