# AEM Breakdown Guidelines

## Objective

Turn AEM responsibilities into Component-, Template-, Content-, or Publishing-level Work Items and confirm the actual Workspace／Repo／Site and Target Asset. If the SD explicitly says AEM is `none`, output No Change internally and do not generate Grill questions or Tasks.

## 1. Extract AEM scope

Check for Site, Section, Page, Template, Component, Dialog, Content Model, Content／Experience Fragment, DAM Asset, Authoring, Workflow, Approval, Publishing, Cache, Release, wording, PDF, links, localization, and downstream content consumers.

Distinguish code changes, content changes, and publish-only work. Do not label every item Component Development.

## 2. Group Work Items

Group by Enhance／New Component, Template／Dialog／Content Model, Content／Asset Preparation, Workflow and Publishing, or Content Release Enablement. Fields, dialog options, and styling for one Component normally remain one Task.

## 3. AEM Grill sequence

1. Which Workspace／Repo, Site, and Section are affected?
2. Is this Enhance Existing or New Component?
3. Are Template, Dialog, or Content Model changes needed?
4. Is content held in a Page, Content Fragment, or DAM Asset?
5. Is this Authoring／Publishing only with no code change?
6. Who owns Author／Publish, Workflow, Cache, and Release?

If unknown, mark `TBD — AEM Owner Review` internally; never guess component paths.

## 4. Dependencies and output

Track wording, PDF, translation, compliance approval, content-version, and release-order dependencies internally. Do not redesign Mobile／API consumers or create B/E tasks. Avoid AEM Java, Sling Model, and code design.

For non-code content managed outside AEM, use the actual Content／Configuration Platform as Component and its management Location instead of forcing a code Workspace. Final output follows the simplified template only.
