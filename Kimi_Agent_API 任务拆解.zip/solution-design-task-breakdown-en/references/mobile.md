# Mobile Breakdown Guidelines

## Objective

Turn Mobile responsibilities into Journey-, Page-, interaction-, or shared-capability-level Work Items and use Grill to confirm the Workspace／Repo, Module, and Target Component. Do not create a Task for every UI element or function.

## 1. Extract Mobile scope

Check the evidence for:

- Landing／entry, Lite Mode, and visibility;
- Reuse of Segment, Address, or other Common Capabilities;
- Pages, forms, prefill, validation, and empty-value behavior;
- Consent, notes, static wording, and local assets;
- Page state, re-entry, retention, and reset;
- Navigation, overlays, modals, and error pages;
- API timing, duplicate taps, and result presentation;
- PDF, dialing, configuration, footprint／analytics;
- Release and backward-compatibility needs.

Preserve responsibilities assigned by the SD. Do not add API validation when the SD assigns it to Mobile, or vice versa.

## 2. Group Work Items

Group by user-recognizable capabilities such as Entry and Eligibility, Form Page and Validation, Navigation, Error and Contact Support, Submission and Acknowledgement, Local Content and Configuration, and Logging／Release.

Amount, Preferred Time, Name, and Mobile Number in one form normally belong to one Form Work Item. Separate a shared capability only when it has an independent reuse or ownership boundary.

## 3. Identify reuse and No Change

Distinguish enhancing an existing Page／Component, adding a journey-specific Component, calling an existing Common Capability without changing it, adding Config／Assets, navigating to an existing journey whose internals are out of scope, and No Change.

Using an existing capability does not imply modifying it.

## 4. Mobile Grill sequence

1. Which Workspace／Repo, Module, and Landing Component own the entry?
2. Is the page an enhancement of an existing form or a new Page／Component?
3. Which Common Capabilities are reused without modification?
4. Are Error Page, Overlay, PDF Viewer, and Dialer existing components?
5. Which Module／Owner owns configuration, content, and footprint?
6. Which assets remain TBD for Mobile TL review?

Never invent component names when the answer is unknown.

## 5. Dependencies and output

Track API timing, existing journey dependencies, content blockers, app-version and release risks internally. Keep B/E implementation out of Mobile Tasks.

Internally track related FPs, journey, Workspace／Repo, Module, Target Asset, change type, overall scope, dependencies, open items, and outcome. Final output follows the simplified template only, without UI code, class names, state-management design, or test-case tasks.
