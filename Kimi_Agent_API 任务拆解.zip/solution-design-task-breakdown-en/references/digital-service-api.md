# Digital Service API Breakdown Guidelines

## Objective

Group Digital Service responsibilities into Endpoint-level Work Items and confirm the Workspace／Repo, PAPI, Endpoint, and Enhance／New decision. Do not produce detailed API contracts or code implementation.

Follow this sequence:

1. Identify FPs that need Digital Service capabilities;
2. Decide whether capabilities belong in one Endpoint;
3. Use Architecture／Group Standards to choose Enhance Existing or New;
4. Assess compatibility, SLA, capacity, and downstream impact;
5. Use Grill to confirm the Workspace／Repo and Target Endpoint.

## 1. Build the API Capability Map

For each relevant FP, extract:

- Caller and trigger;
- Business purpose;
- Query versus Command;
- Conceptual input, output, and sensitive-data scope;
- Success, failure, timeout, side-effect, and retry semantics;
- Downstream SAPIs and synchronous／asynchronous relationships;
- Explicit out of scope.

Do not move Mobile Common Capabilities or frontend-only work into the API.

## 2. Decide whether capabilities share an Endpoint

Ask whether they form one complete business operation before considering the 24-second budget.

### Core dimensions

- Same caller and invocation timing;
- Same business purpose and complete action;
- Same Query／Command and read／write semantics;
- Same success, failure, and partial-completion semantics;
- Same side effects, idempotency, and retry behavior;
- Compatible consistency, sensitivity, and data-minimization needs;
- Cohesive Request／Response;
- Shared versus independent change and release lifecycle.

### Signals to merge

- One caller performs one business action;
- Capabilities always execute together;
- They can be retried safely as one unit;
- Success／failure and data-security semantics align;
- They generally change and release together.

### Signals to split

- Query mixed with Submit／Command;
- Different invocation timing or independent retries;
- Different success, failure, or partial-completion semantics;
- Independent release or fault-isolation needs;
- Different data sensitivity;
- Extensive `mode/action` branching;
- Merging only to reduce URL or request count.

Multiple internal SAPI calls may belong to one Submission Endpoint. Do not expose every SAPI as a separate PAPI Endpoint.

## 3. Assess three reuse layers separately

Record independently:

1. Reuse a B/E SAPI;
2. Reuse a PAPI／microservice;
3. Reuse an existing Endpoint.

SAPI reuse does not prove Endpoint reuse. A New Endpoint does not imply a New Microservice. Shared domain alone is insufficient justification for Enhance.

## 4. Use standards to choose Enhance or New

### Default to reuse

Follow the current Architecture／Group Standard and investigate Existing Endpoints first. Where AMH or another designated implementation standard applies, check its patterns and assets before proposing New. Deviation requires concrete reasons, risks, business impact, and required Architecture／Business Approval.

Shift architectural constraints and reuse direction left into Solution Design where practical, but do not require the SD to name a Workspace or Endpoint. Discover missing assets through investigation and Grill.

### Enhance Existing checklist

Enhance only when the existing Endpoint represents the same business operation. Investigate:

- Workspace, Repo, PAPI, URL, Method, and Owner;
- Current purpose, Request／Response, logic flow, and downstream chain;
- Existing consumers and older callers;
- Backward compatibility of required fields, defaults, nulls, enums, and errors;
- Impact on original functions／flows, extra SAPI calls, and sensitive data;
- Journey-specific branching and regression, release, and rollback risk.

An absent parameter may legitimately select the original flow for backward compatibility. Challenge silent fallback for invalid values because it hides caller defects. Leave serialization and code-branch design to technical design.

### New Endpoint checklist

Show that Enhance risk or cost exceeds the cost of New plus governance. Record required Architecture Review／Board Approval, Endpoint／Service Registration, API Owner, release dependencies, and maintenance responsibility.

Evidence may include incompatible business semantics or contracts, little genuine reusable logic, consumer regression risk, proven performance／fault-isolation／security constraints, and an Enhance-versus-New risk-cost comparison. Different Request／Response fields are only a signal; explain the actual compatibility risk.

## 5. Reassess SLA, capacity, downstream impact, and security

Do not reuse the old SLA conclusion without assessment or try to prove zero timeout risk during breakdown.

- Obtain production Average, P95／P99, and the current call chain;
- Assess new synchronous SAPI, processing, gateway, and network overhead;
- Distinguish serial from parallel calls and avoid double-counting reused latency;
- Check the end-to-end budget, such as a 24-second gateway limit, with headroom;
- Leave measurement, detailed timeout values, and optimization to later validation;
- Distinguish Mobile→PAPI traffic growth from PAPI→SAPI growth and per-request work growth;
- Flag Pod, pool, and downstream quota risks without calculating values;
- Add capacity-change Work Items only after the TL confirms a real risk;
- Check masking, sensitive-data exposure, logging, permissions, and audit impact.

## 6. API Grill sequence

Ask one question at a time:

1. Is there a similar capability, such as Long Form supporting Short Form?
2. Which Workspace／Repo／PAPI contains it?
3. What is the exact existing Endpoint and its current purpose?
4. Is this the same operation, and should it be Enhance or New?
5. Does it meet Group Standard／AMH, or need deviation approval?
6. Who confirms consumer and original-flow impact?
7. What production data or owner validation is needed for SLA and capacity?
8. Does New require Architecture Review and Registration?

If unknown, mark `TBD — API TL Review` internally and continue.

## 7. Internal Endpoint Work Item content

Track related FPs, purpose, trigger, change type, assets, overall scope, SAPI integration, consumer impact, approvals, NFR risks, open items, and expected outcome internally. Final output follows the simplified output template only.

Do not split reference generation, logging, field mapping, or unit tests into separate Tasks.
