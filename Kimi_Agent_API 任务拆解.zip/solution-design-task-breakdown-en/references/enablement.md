# Third-party and Delivery Enablement Guidelines

## Objective

Identify delivery prerequisites beyond the Component Design table, including third-party, network, security, platform, and release enablement. Generate only evidence-based or clearly labeled proposed work. Never break down B/E implementation.

## 1. Scan trigger signals

Inspect interactions, dependencies, timeout assessments, open items, out of scope, and prose for:

- `third-party`, `vendor`, `external service`;
- `whitelist`, `firewall`, `proxy`, `DNS`, `network route`;
- `certificate`, `mTLS`, `secret`, `credential`;
- `security review`, `privacy`, `PII`, `approval`;
- `configuration`, `feature flag`, `deployment`, `release`;
- `sandbox`, `test account`, `content`, `migration`;
- `monitoring`, `alert`, `runbook`, `support`.

Absence of Network or Security from the component table does not prove that no enablement is needed.

## 2. Assess third-party needs

Classify each as Already Available, Required, Potentially Required, or Not Applicable:

- Vendor onboarding, procurement, and risk assessment;
- API integration and sandbox;
- Whitelist, firewall, proxy, and DNS;
- Certificate, mTLS, credential, and secret;
- Test accounts, test data, and integration windows;
- PII, privacy, and security review;
- Quota and rate limits;
- Monitoring, alerts, vendor support, and escalation.

Do not duplicate enablement when an integration already exists. If whitelisting is inferred from third-party usage rather than explicit in the SD, treat it as Proposed Enablement or Investigation.

## 3. Network, security, and Release Notes

If whitelisting, certificates, or approvals do not block development start but may block release, output only a concise Release Note, for example:

`- FP-XXX: Confirm the third-party PROD whitelist before release.`

Caller, destination, environment, domain／IP, port, protocol, NAT／egress, Owner, and lead time may be checked internally. Do not output a network-parameter table, firewall commands, or implementation steps.

Only actual Digital code, content, or configuration changes belong in Task List, using the actual Workspace／Location and Target Asset.

## 4. Platform, content, and release

Check for configuration, feature flags, secrets, environment setup, test data, release order, content initialization, migration, wording, PDFs, monitoring, alerts, runbooks, rollback, support handover, and required approvals.

Add Pod, connection-pool, or quota changes only after the TL confirms a real capacity risk; do not invent values.

## 5. Enablement Grill sequence

1. Is there an existing third-party or platform integration to reuse?
2. What are the Vendor, Service, Network Path, and Environment?
3. Which enablement already exists and what is new?
4. What is the approval lead time and release blocker?
5. Which parameters remain with Network／Security／Vendor Owners?

If unknown, mark TBD internally and continue.

## 6. B/E boundary

Analyze B/E SAPI dependencies internally. In the relevant API Task, state the purpose and whether an existing call is reused or a new call assessed. Do not create B/E design Tasks, development Tasks, or a separate dependency table, even when a SAPI change might be needed.
