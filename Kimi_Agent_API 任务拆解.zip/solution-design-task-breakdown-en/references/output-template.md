# Task Breakdown Output Template

Produce exactly two final sections, `Task List` and `Release Notes`, with no tables. Keep the Coverage Matrix, Decision Log, Risk Register, and Dependency Register internal.

# [Requirement／Journey] Task Breakdown

## 1. Task List

Group by actual Component. Use one Task per Endpoint for API and one Task per Page／Component／Content Asset for Mobile, AEM, and other content／configuration platforms. One Task may relate to multiple FPs; never duplicate a Target Asset by FP.

### [Task name]

Component: [Mobile／AEM／Digital Service API／actual content or configuration platform]  
Workspace／Location: [Code Workspace／Repo or non-code management location; TBD if unknown]  
Target Asset: [Endpoint／Page／Component／Content Asset; TBD if unknown]  
Change Type: [Enhance／New]  
Related FP: [FP-XXX, FP-XXX]

Changes:
- [Overall business, page, or content change.]
- [Key validation, processing, or integration.]
- [For API, identify relevant SAPI calls as reuse or new-call assessment.]

Rules:

- Keep only the fields and change bullets above. Do not add Business Purpose, Risk, Owner, Expected Outcome, or other fields.
- Describe business processing, key validation, SAPI calls, and major outcomes, not classes, annotations, methods, or code.
- If Grill cannot confirm Workspace／Location or Target Asset, mark that field TBD and continue.
- Use the actual Location for content or configuration work; do not force a code Workspace.
- Name the actual delivery platform as Component. Use `F/E Content／Configuration (TBD)` only when the platform is unknown.

## 2. Release Notes

Use concise bullets only for items that do not block development start but may block release:

- [Related FP／Task] Confirm the third-party PROD whitelist before release.
- [Related FP／Task] Complete required approvals, certificates, configuration, or release preparation.

Do not expand network parameters, owner matrices, or implementation steps here. Do not move actual code／content changes into Release Notes.

## Internal self-check

- Every FP maps internally to a Task, No Change, or Out of Scope;
- No Endpoint／Component is duplicated by FP;
- B/E SAPIs appear only in API change bullets, with no B/E Tasks or dependency table;
- Every Workspace／Location and Target Asset is confirmed or TBD;
- Third-party, whitelist, approval, and release reminders are included;
- Output contains only Task List and Release Notes and uses no tables.
