---
name: solution-design-task-breakdown-en
description: Break down a Solution Design Report into Digital delivery Work Items and use focused, one-at-a-time Grill questions to confirm the actual Workspace, Repo, Endpoint, Mobile Component, AEM Component, content location, and enablement needs. Covers Mobile, AEM, Digital Service APIs, third-party services, network, security, platform, and release readiness. Records B/E dependencies only inside relevant API change descriptions and never breaks down B/E implementation. Use when the user asks for a task list or component breakdown from solution design, needs to choose enhance-existing versus new assets, or wants an existing breakdown reviewed. Not for detailed technical design or developer-level task cards.
---

# Solution Design Task Breakdown

## Objective

Preserve the business decisions in the Solution Design and turn Function Points, external dependencies, and delivery constraints into reviewable Work Items. Use Grill to establish what changes, where it changes, which asset changes, and the overall scope. Do not redesign the business solution or descend into code-level implementation.

Output Markdown by default. Create a file only when requested.

## Scope

### In scope

Dynamically select Mobile, AEM, Digital Service API, Third-party, Network, Security, Platform, Content, Configuration, and Release workstreams when supported by evidence. Do not invent work to fill a template.

### Out of scope

- Do not break down B/E design, development, configuration, or deployment. Analyze SAPI dependencies internally and mention reuse or a new call only in the relevant API Task.
- Do not produce class design, JSON serialization, method names, or detailed code structures.
- Do not split field mapping, logging, or unit tests into separate developer task cards by default.
- Never invent Workspaces, Repos, Endpoints, Components, Owners, consumers, or production data.

Calling a SAPI from Digital Service is PAPI integration work. Changing the SAPI itself is outside this Skill.

## Read references on demand

Read only the guidelines needed for the current work:

- Digital Service API: [references/digital-service-api.md](references/digital-service-api.md)
- Mobile: [references/mobile.md](references/mobile.md)
- AEM: [references/aem.md](references/aem.md)
- Third-party and delivery enablement: [references/enablement.md](references/enablement.md)
- Final output: [references/output-template.md](references/output-template.md)

When reviewing an existing breakdown, load only relevant component guidelines and use Grill to challenge omissions and unsupported conclusions.

## Information states

Distinguish:

- `Confirmed by SD`: Explicit in the Solution Design.
- `Confirmed by Asset Investigation`: Confirmed from code, an API catalogue, or implementation material.
- `Confirmed by User`: Confirmed during Grill.
- `Proposed`: A recommendation awaiting owner review.
- `Assumption`: Needed to proceed but not yet verified.
- `TBD`: Requires investigation; not automatically an SD blocker.
- `Open Item`: Requires a decision by an identified role.

Never present an inference as an SD fact. Unknown Repos, Endpoints, detailed contracts, or production data do not prevent a Draft Breakdown.

## Workflow

### 1. Establish the breakdown basis

Read the complete Solution Design, including interactions, component design, B/E dependencies, timeout assessment, open items, and out of scope. Extract:

- Version, requirement source, and FP list;
- Component responsibilities, business rules, and success/failure semantics;
- External dependencies, NFR constraints, and release prerequisites;
- Confirmed decisions, implementation investigations, technical design items, and open decisions.

Raise an `SD Gap` only when a missing business decision would force you to redesign the solution. An unknown Endpoint or Workspace is not an SD Gap.

### 2. Build internal coverage and dependency inventories

Assign every FP an internal result: Work Item, No Change, or Out of Scope. Assign every external dependency an internal result: Reuse, Integration, Enablement, Investigation, or External Dependency Only.

Scan for third-party services, whitelisting, certificates, secrets, configuration, content, and release requirements. Absence from the component table does not prove absence of delivery work.

### 3. Group capabilities into Draft Work Items

Do not mechanically map one FP to one Task or Endpoint. Preserve FP traceability while grouping by target asset:

- API: one Task per Endpoint;
- Mobile, AEM, and other content/configuration platforms: one Task per Page, Component, or Content Asset;
- Enablement: group actual delivery changes by Target Asset; put release-only reminders in Release Notes.

One Task may relate to multiple FPs.

### 4. Load component guidelines and complete the draft

Add Target Asset candidates, Change Type, Change Scope, dependencies, risks, assumptions, and out of scope using the relevant references. Use `Proposed` or `TBD` when asset evidence is unavailable.

### 5. Grill to confirm Target Assets

Present the current understanding and candidate, then ask one key question at a time. Converge one Work Item before moving to the next; do not send a full questionnaire.

Grill only to establish:

1. Whether an existing capability can be reused;
2. Its Workspace／Repo or non-code Location;
3. The exact Endpoint, Module, Page, Component, Template, or Content Asset;
4. Enhance Existing versus New;
5. Existing flow／consumer impacts, Owners, and approvals;
6. Third-party or platform enablement.

Do not revisit business rules settled in the SD. Do not ask about JSON annotations, classes, method names, Pod counts, or similar implementation details.

Suggested question:

> This Work Item needs [capability]. I understand it may reuse [candidate] in [Workspace, if known]. Can you confirm the actual Target Asset and whether this is Enhance Existing or New?

If the user does not know, mark the field `TBD`, optionally note the suggested reviewing Owner internally, and continue with the next Work Item. Do not block the entire breakdown.

Use asset states internally: Confirmed, Proposed, TBD — Owner Review, New — Approval Required, and No Change. Track the source: SD, User Confirmation, Repo Inspection, API Catalogue, or Owner Review.

### 6. Close risks and decisions internally

Keep the Coverage Matrix, Decision Log, Risk Register, and Dependency Register internal. Do not output them.

Do not create B/E Work Items. When an API Task integrates with a SAPI, state in its change bullets whether the existing call is reused or a new call must be assessed. Treat possible SAPI changes only as internal risks or Grill prompts.

Put actual code, content, or configuration changes in Task List. Put whitelist, approval, certificate, and release prerequisites that do not block development start but may block release in Release Notes.

### 7. Output and self-check

Read the output template. Produce exactly two final sections, `Task List` and `Release Notes`, with no tables. Verify:

- Every FP, dependency, and key constraint was handled internally;
- API Tasks are by Endpoint and other Tasks by Target Asset, with multiple FPs allowed;
- Each Task contains only Component, Workspace／Location, Target Asset, Change Type, Related FP, and change bullets;
- Unconfirmed Workspace／Location or Target Asset fields are marked TBD without stopping later work;
- No B/E implementation Tasks, analysis tables, or technical design details are present;
- Enhance Existing decisions consider existing flows and consumers;
- Third-party and release reminders appear in Release Notes.

For interactive Grill, provide a short Draft Summary, ask questions one at a time, and produce the Final Breakdown only after key questions are answered or marked TBD.
