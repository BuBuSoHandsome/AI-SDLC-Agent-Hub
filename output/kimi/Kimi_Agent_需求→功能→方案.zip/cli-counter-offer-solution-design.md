# 信用卡额度调升（CLI）Counter Offer Solution Design

> 版本：v0.1 | 状态：Draft
> 范围声明：本文档覆盖手机银行 App、网页版（AEM）、Digital Service 能力需求。
> 不含 endpoint/契约设计与 component 选型（任务拆分环节确定）；
> 不含后端系统内部实现，后端仅作为依赖列出。

---

## 1. 概述

| 项 | 内容 |
|---|---|
| 业务背景 | 现有 CLI 流程（Input → Confirm → Ack）中，客户申请额度过高时直接拒绝，造成客户流失。本需求新增 Counter Offer 环节：申请额超出即时审批上限时，向客户提供一个可即时审批通过的金额，提升获批率 |
| 渠道范围 | ☑ 手机银行　☑ 网页版　【假设：两端都上，待确认】 |
| 方案一句话 | 在 CLI 提交流程中插入 Counter Offer 分支：Digital Service 新增"Counter Offer 查询"能力（调用 omnibase 的 counter offer SAPI），当申请额超上限时前端跳转新增 Counter Offer 页，展示可即时审批金额，客户接受后沿用现有 Confirm → Ack 流程完成申请 |

## 2. 功能分析

### 2.1 范围

**In Scope**
- Counter Offer 判定与金额获取（Service 新增能力）
- Counter Offer 页面（新增页面：展示可即时审批金额 + 接受/拒绝）
- 客户接受后按 counter offer 金额完成 CLI 申请（复用现有 Confirm/Ack 流程）

**Out of Scope**
- omnibase 侧 counter offer 的审批策略与额度模型（B/E 内部实现）
- 柜台/客服渠道的 counter offer（本期仅 digital）

### 2.2 功能点清单（六视角分析结果）

| # | 功能点 | 实现方 | 依赖系统 | 依赖类型 | 六视角发现 |
|---|---|---|---|---|---|
| 1 | CLI 申请提交 | Digital（Service） | omnibase | 改造 | 账务：原同步返回批准/拒绝，现新增"转 counter offer"分支；页面状态枚举需扩展 |
| 2 | Counter Offer 金额获取 | Digital（Service） | omnibase（counter offer SAPI） | **新增** | 合规：展示金额即"银行要约"，页面文案需合规审阅【待确认】；金额是否有时效【Open】 |
| 3 | Counter Offer 页显示 | Digital（App + AEM） | 无新依赖（数据来自能力2） | — | 客户视角：必须清楚表达"此金额可即时获批"，避免与"申请中"混淆 |
| 4 | 接受/拒绝 Counter Offer | Digital（Service） | omnibase | 改造【假设：接受需回传 omnibase 确认，待确认】 | 账务：接受 = 以新金额正式提交申请，状态映射同现有 CLI；拒绝后走向【Open】 |

### 2.3 非功能需求
- Counter offer 查询响应 < 1s（P95）【假设，待确认】
- 金额为敏感信息，传输加密；页面展示不脱敏（客户本人已登录）【假设】
- 涉及授信要约，接受动作需留痕可审计

## 3. 整体架构

```
手机银行 ──┐
          ├──→ Digital Service ──→ omnibase（改造：CLI 提交返回 counter offer 分支
网页版 ──┘        │                   新增：counter offer SAPI）
                 └──→ AEM CMS（counter offer 页说明文案）
```

## 4. 渠道方案

### 4.1 手机银行

**页面清单**

| # | 页面 | 改动类型 | 改什么内容 | 所需数据 |
|---|---|---|---|---|
| 1 | CLI Input 页 | 修改 | 提交后处理"转 counter offer"分支，跳转 Counter Offer 页 | 能力1 |
| 2 | **Counter Offer 页** | **新增** | 展示：客户申请金额 + 可即时审批金额；操作：接受（进入 Confirm）/ 拒绝【走向 Open】；说明文案（AEM 维护）【假设文案静态，待确认】 | 能力2 |
| 3 | CLI Confirm 页 | 修改 | 支持以 counter offer 金额进入（金额来源标识为 counter offer，防止客户再改回高金额） | 能力3 |
| 4 | CLI Ack 页 | 修改 | counter offer 路径的结果展示文案 | 能力3 |

- **页面流程图**：Input →（系统判定）→ [批准：Confirm → Ack] / [超上限：**Counter Offer 页** → 接受 → Confirm → Ack] / [拒绝：?]
- **端上逻辑**：仅按钮级交互；金额判定、可用性校验全部在 Service 侧
- **特殊考量**：客户中途退出后再次进入 CLI，是否重新判定【Open】

### 4.2 网页版（AEM）

**页面清单**

| # | 页面 | 改动类型 | 改什么内容 | 组件意向 | 所需数据 |
|---|---|---|---|---|---|
| 1 | CLI Input 页 | 修改 | 同 App：分支跳转 | 复用 | 能力1 |
| 2 | Counter Offer 页 | 新增 | 同 App | 新建（意向） | 能力2 |
| 3 | Confirm / Ack 页 | 修改 | 同 App | 复用 | 能力3 |

- **内容边界**：counter offer 页的说明文案（如"根据您的财务状况，我们可即时为您提升至以下额度"）由 AEM 作者维护；金额等数据全部来自 Service

## 5. 跨渠道一致性

| 功能点 | 手机银行 | 网页版 | 柜面 | 说明 |
|---|---|---|---|---|
| Counter offer 展示与接受 | ✔ | ✔ | ✘ | 本期仅 digital，柜面【Open：客户拿 counter offer 截图去柜台怎么办】 |
| 金额与规则 | 一致 | 一致 | — | 规则统一在 omnibase，两端无差异 |

## 6. Digital Service 能力设计

### 6.1 能力清单

| # | 能力 | 提供的数据 | 同步/异步 | 数据来自 | 失败语义 |
|---|---|---|---|---|---|
| 1 | CLI 申请提交（改造） | 审批路径（直接批准/转 counter offer）+ 申请上下文 ID | 同步 | omnibase | 阻断 |
| 2 | **Counter Offer 查询（新增）** | 可即时审批金额、（时效？）【Open】、关联的申请上下文 ID | 同步 | omnibase counter offer SAPI | 阻断（拿不到金额则不展示该页，按原拒绝流程走【假设，待确认】） |
| 3 | Counter Offer 接受提交 | 受理结果（已受理/已批准）、额度生效信息 | 同步 | omnibase | 阻断 |

### 6.2 能力详述

**能力 2：Counter Offer 查询**
- 输入：申请上下文 ID（来自能力1）
- 输出数据：可即时审批金额、有效期【Open】、上下文 ID
- 行为语义：金额以 omnibase 返回为准，端上不做任何计算；金额不等于申请额时不允许客户修改
- 失败语义：阻断——查询失败则不进入 Counter Offer 页，走向【Open：按原拒绝流程 or 提示重试】

**能力 3：Counter Offer 接受提交**
- 输入：上下文 ID + 客户确认动作
- 输出数据：受理结果、生效额度、预计生效时间
- 账务状态映射：客户可见"已受理" ↔ omnibase 记账状态由后端处理；若即时审批则直接显示"已批准"【假设：counter offer 是即时批准，待确认】
- 行为语义：**必须幂等**——客户重复点"接受"不产生第二笔申请；留痕：接受动作 + 展示过的金额 + 时间戳
- 失败语义：阻断，提示稍后重试，counter offer 是否仍有效由上下文 ID 保证【Open】

### 6.3 关键链路时序图

```
Input页提交 → Service(能力1) → omnibase 判定
   ├─ 直接批准 → Confirm → Ack
   └─ 转 counter offer → Service(能力2) → omnibase counter offer SAPI
        → Counter Offer 页展示金额
        → 客户接受 → Service(能力3) → omnibase 确认 → Confirm → Ack
        → 客户拒绝 → 【Open】
```

### 6.4 供给通则
- 能力1 与能力2 串行（能力2 依赖能力1 的上下文 ID）；无并行场景
- 数据时效：counter offer 金额为实时判定结果，不做缓存

## 7. 后端依赖清单

| # | 对应能力 | 后端系统 | 类型 | 需求描述 | 负责人 | 状态 |
|---|---|---|---|---|---|---|
| 1 | 能力1 | omnibase | 改造 | CLI 提交返回新增"转 counter offer"分支 + 上下文 ID | | 待确认 |
| 2 | 能力2 | omnibase | **新增** | counter offer SAPI：输入上下文，返回可即时审批金额（+时效） | | 待确认 |
| 3 | 能力3 | omnibase | 改造 | 接受 counter offer 的确认接口（幂等、留痕） | | 待确认 |

## 8. 非功能设计
- 性能：能力2 与页面跳转串联，目标整体 < 1.5s
- 异常体验：能力2 超时/失败 → 不展示 Counter Offer 页【走向 Open】；能力3 失败 → 明确提示"未提交成功"，允许重试
- 安全：登录态校验；金额为授信要约信息，服务端返回，端上不可篡改；接受动作留痕
- 监控：能力2 调用量与转化率（展示→接受）埋点——这是本需求的核心业务指标

## 9. 备选方案与取舍

| 方案 | 优点 | 缺点 | 结论 |
|---|---|---|---|
| A. Service 调 omnibase，前端只展示 | 规则集中、两端一致 | Service 多一跳 | ✅ 采用 |
| B. 前端分别直连 omnibase | 链路短 | 两端重复逻辑、判定口径可能不一致 | 放弃 |

## 10. 风险与 Open Items

| # | 项 | 类型 | 说明 | 负责人 | 期限 |
|---|---|---|---|---|---|
| 1 | 拒绝后走向 | Open | 客户拒绝 counter offer：保留原申请进入人工审核？还是直接结束？ | BA | |
| 2 | Counter offer 时效 | Open | 金额是否有有效期；中途退出再进入是否重新判定 | omnibase | |
| 3 | 能力2 失败的兜底走向 | Open | 拿不到金额时按原拒绝流程 or 提示重试 | BA | |
| 4 | 合规审阅 | 风险 | counter offer 页文案涉及授信要约，需合规确认 | 合规 | |
| 5 | 渠道范围 | Open | 本期是否含网页版；柜面场景如何回应 | BA | |
| 6 | 能力3 幂等与上下文有效性 | Open | 重复接受、超时后接受的处理 | omnibase | |
```
