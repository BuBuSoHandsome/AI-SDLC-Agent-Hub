---
name: digital-solution-design
description: 银行 Digital 团队的 Solution Design 产出工具。覆盖三个 area：Mobile（手机银行 App）、AEM（网页版）、API（Digital Service 能力需求）；不含 endpoint/契约设计与 component 选型（留给任务拆分环节），不含后端底层实现。产出为三段式文档（E2E Diagram / Party 职责与边界 / Out of Scope & Open Items），粒度供 Technical Lead 拆分各 party 任务。内置 Grill 环节：动笔前逐个主动向用户追问关键设计问题。支持多 team 差异（card/payment/banking 等）与公司标准加载；支持以已有方案文档为输入的增量更新。当用户要求基于需求出方案设计、solution design、技术方案，或评审、更新已有 digital 方案时使用。
---

# Digital Solution Design

## 必读（最高优先级）

**产出任何 solution design 之前，必须先阅读 references/standards/solution.md（公司级标准）。**
产出内容与该标准冲突时，以标准为准，偏离处写入 Open Items。

## 设计边界

- 范围内三个 area：Mobile（页面与内容）、AEM（网页版页面与内容）、API/Digital Service（能力需求：提供什么数据、什么行为、失败怎么办）
- 范围外（留给任务拆分环节）：endpoint 划分与命名、契约细节、component 选型
- 范围外（留给后端团队）：后端系统内部实现、DB、MQ——只列依赖（到 SAPI 名为止），不做设计
- 边界外的事不做设计，但须追问其对前端的外露影响（如通知丢失的兜底感知、人工审核的中间状态）
- 链条定位：功能分析 → Grill → **产出方案** → TL 拆分任务（下游是任务拆分者，不是开发）

## 工作流程

0. **读标准**：阅读 references/standards/solution.md
1. **识别 team 并加载差异层**（见下节）
2. **功能分析**：按 team 的拆解角度拆功能点（拆解规则见下）
3. **Grill 环节**：逐个主动追问，问到完全 clarify（规则见下）
4. **按模板产出**：复制 assets/solution-design-template.md 填充（三段式）
5. **自查**：过 references/checklist.md 兜底

### 功能点拆解规则（全 team 统一）

- 以「客户/系统的一次完整动作」为单位拆，不以技术组件为单位
- 一个动作若有独立的依赖系统或独立的失败语义，拆成独立功能点
- 自检：每个功能点能归到某个 party 的「要做什么」里，归不进说明粒度不对
- 拆解方法各 team 一致；team 差异只体现在 Grill 问题与系统版图

### 增量更新模式（delta change）

输入含已有方案文档 + 变更需求时：功能分析与 Grill 仅覆盖变更点；沿「party 职责」检查波及面；版本号 +1、状态重置为 Draft、填写文末「变更记录」。

## Team 识别与差异层

team 与业务是多对多关系（如 CAL team 同时负责 card 和 loan）。识别路由：
1. 扫 references/teams/{team}/scope.md 的路由关键词匹配需求
2. 命中一家 → 声明推断结果，给用户纠正机会；命中多家 → 按主要工作面判断，判断不了就问；都没命中 → 直接问
3. 需求跨多 team 时：主 team 主导，同时加载相关 team 的 grill-questions 作为补充追问

确认 team 后加载三份文件：
- scope.md：本 team 负责的业务域与边界（检查需求是否真的归该 team）
- grill-questions.md：本 team 特有追问（team 自治，与 common 合并使用）
- system-map.md：本 team 常用系统索引（事实以全局 references/system-map.md 为准；Grill「调到哪个服务」与方案中的 SAPI 名均从全局版图查）

冲突优先级：**公司标准（standards/solution.md）> team 配置 > skill 默认**
新 team 接入：照 references/teams/README.md 的格式补三份文件，底座不动。
team 的 scope/profile 未填写时，退回 common 题库兜底。

## Grill 环节（动笔前必做）

交互规则：
- **一次只问一个问题**，得到回答再问下一个；不一次性列问题清单
- **由浅入深**：先业务行为，再语义（时效/重复提交），最后边界类（通知兜底、中间状态外露）
- **问到服务名为止**：只确认调哪个后端服务/SAPI、需要什么数据；内部实现不追问、不假设
- 提问必须具体带场景（说"客户连点两次接受会怎样"，不说"要考虑幂等"）
- 用户答不上来的，标为 Open Item 继续推进——不阻塞、不替用户假设
- **不设数量上限**：按风险排序逐个问，问到完全 clarify 为止

## 粒度标准

- **API / Digital Service**：精确到「能力」——提供什么数据、同步/异步、行为语义（时效/重复提交/送达兜底）、失败语义（阻断/降级）。不出现 endpoint
- **Mobile / AEM**：精确到页面——改哪些页面、每页改什么内容、所需数据可追溯到能力
- **下游服务**：到 SAPI 名 + 需要什么（复用/改造/新增）；涉及第三方（非银行内服务）必须检查白名单
- 验收：TL 拿任意 party 一节能直接拆任务，不需要回来问"到底要给什么数据"

## 输出

- Markdown 文档，命名：{功能名}-solution-design.md
- 三段式：① E2E Diagram（Mermaid，party + 调用关系，新增高亮）② Party 职责与边界 ③ Out of Scope & Open Items
