---
name: digital-solution-design
description: 银行 Digital（HASE Digital）的 Solution Design 产出工具。接收需求文档后：按完整动作粒度拆分功能点 → 判定涉及 Party（Mobile/AEM/API，及 B/E 依赖）→ 逐功能点 Grill 用户（party 职责与 solution 决策）→ 产出 function point-to-party-to-solution 的 solution design report（Markdown）。覆盖 Mobile（手机银行 App）、AEM（网页版）、API/Digital Service 三个 area；不定 endpoint/契约设计与 component 选型（留给 technical design），不设计 B/E 内部实现，但要列明用到的 B/E 服务（SAPI 名）。内置 Grill 环节：动笔前逐个主动追问关键设计问题。当用户提供需求文档要求出 solution design、技术方案、方案设计，或要按功能点拆分需求并划分各 party 职责时使用。
---

# Digital Solution Design

接收需求文档，产出 solution design report。下游读者是 Technical Lead（据此拆各 party 任务），不是开发。

## 设计边界

- 范围内：Mobile、AEM、API/Digital Service（能力需求：提供什么数据、什么行为、失败怎么办）
- 范围外（留给 technical design）：endpoint 划分与命名、契约细节、component 选型、字段级细拆
- 范围外（留给 B/E 团队）：B/E 内部实现——只列依赖（到 SAPI 名为止），不做设计
- 不做增量更新模式：每次按完整新需求处理

## 必读（最高优先级）

**任何产出之前，必须先读 references/集团标准.md。** 产出内容与集团标准冲突时，以标准为准，偏离处写入 Open Items。

## 加载机制

1. references/集团标准.md → 必加载，最先加载
2. references/Mobile.md / references/AEM.md → 按需求文档的 Channel 字段加载；多渠道则都读，F/E 共性问题按渠道各问一次、答案分别记录
3. references/API.md → 必加载（默认需求都涉及 API）
4. references/BE.md → Grill 中确认涉及 B/E 依赖时加载
5. references/report-template.md → Step 5 产出时加载

## 工作流程

### Step 1 功能点拆解（完整动作粒度）

三判据，全部满足才算一个功能点：
1. 独立业务结果：动作完成后客户或银行得到有价值的结果
2. 独立触发：由客户或系统的独立意图触发，不是另一动作的中间步骤
3. 独立失败语义：失败时需单独处理/兜底

补充条款（守门动作）：系统侧守门检查虽无客户主动触发，但承载独立合规义务且有独立拒绝/引导路径的，独立成点；同一入口的多个准入检查合并为 1 点。

自检：每个功能点必须能映射到至少一个 party 的职责；映射不进说明粒度不对。

### Step 2 Party 判定

- 需求模板的 Channel 字段 → 定 F/E 归属（Mobile / AEM）
- 非纯 wording 改动 → 必有 API
- API 有改动 → 必追其背后 B/E 是否变动
- 极端情形允许 F/E + B/E 改动而 API 不变（少见，遇到需确认）
- 四类主链路外波及面（通知服务 SMS/Email/Push、人工渠道 客服CRM/分行流程、第三方服务、数据下游 报表/监管报送）在 grill 阶段逐项检查；确认涉及的写入报告 3.1 节并视需要转 Open Item；涉及第三方必须检查白名单

### Step 3 Grill 环节（动笔前必做）

- 一次只问一个问题，得到回答再问下一个
- 由浅入深：先业务行为，再语义（时效/重复提交），最后边界类
- 提问必须具体带场景（说"客户连点两次提交会怎样"，不说"要考虑幂等"）
- 问到服务名为止：只确认调哪个 SAPI、需要什么数据；不确定列 Open Item，不编造系统名
- 用户答不上来的标 Open Item 继续推进，不阻塞、不替用户假设
- 不设数量上限，按风险排序问到完全 clarify

### Step 4 Solution 决策

- Party 文件（Mobile/AEM/API/BE）中的 Grill 问题是「意识触发器」：保证关键问题被问到，不写死答案
- 跨 party 的归属裁决（如校验放 F/E 还是 API、鉴权放 API 还是 B/E）由用户当场决定；skill 只负责让每个相关 party 视角的问题都被提出
- 每个决策记录形式：选定方案 + 关键驱动问题的答案
- 偏离集团标准 → 写入 Open Items

### Step 5 产出

- 复制 references/report-template.md 填充
- 输出 Markdown，命名：{功能名}-solution-design.md

## 完成前自检

- 每个功能点过三判据；守门条款已考虑
- 每个功能点有原文依据摘录；未补充原文没有的内容；不确定处标"待确认"
- 报告 3.1 节「其他涉及范围」四项已逐项确认（N/A / 涉及 / 待确认）
- Party 矩阵与功能点详情节内容一致
- E2E 链路图覆盖所有功能点涉及的 party 链路
- 所有 Open Item 关联到 FP 编号并标明 owner 与是否 blocker
