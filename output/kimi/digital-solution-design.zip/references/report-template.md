# {功能名} - Solution Design

> 版本：{Draft v1} ｜ 需求来源：{需求文档名} ｜ 渠道：{Mobile e-banking / AEM / 多渠道}
> 日期：{YYYY-MM-DD} ｜ 作者：{xxx}

## 0. 功能点总览

> 填写指引：功能点按完整动作粒度拆解（三判据 + 守门条款）；
> 原文依据摘录支持该点的原始内容，可用 "..." 省略，不得补充原文没有的内容，
> 不确定标"待确认"。本表只含需求侧信息，不出现 party 与 solution。

| 编号 | 功能点 | 功能点描述 | 原文依据 |
|---|---|---|---|
| FP-001 | {动词+业务对象} | {一句话业务功能} | "{原文摘录}" |
| FP-002 | | | |

## 1. E2E 链路图

> 填写指引：Mermaid flowchart LR，所有功能点共用一张图；
> 逐条列出本需求涉及的调用链路：`{渠道} → PAPI → SAPI（服务名）→ B/E（系统名）`；
> 复用/新增/待确认（OI#n）标注在对应节点后。不画时序、不画交互细节。

```mermaid
flowchart LR
    Mobile --> PAPI --> SAPI_xxx【新增】 --> BE_系统名
    Mobile --> PAPI --> SAPI_yyy（复用） --> BE_系统名2
```

## 2. 功能点详情

> 每个 FP 一节，字段固定；Solution 决策只写"选定什么 + 驱动问题的答案"，
> 不写技术细节（留给 technical design）。

### FP-001 {功能点名}

- **Party 职责**：
  - Mobile：{页面/交互层要做什么}
  - API：{提供什么能力、什么行为语义}
- **B/E 依赖**：{SAPI 名 + 复用/改造/新增 + 需要什么数据/行为}
- **Solution 决策**：{选定的方案 + 关键驱动问题的答案}

### FP-002 {功能点名}
...

## 3. 功能点 × Party 汇总矩阵

> 行 = 功能点（编号与总览一致），列 = Party；格子写关键词级职责，不涉及填 —。
> TL 据此拆任务，详情回查第 2 节。

| Function Point | Mobile | AEM | API | B/E 依赖 |
|---|---|---|---|---|
| FP-001 {功能点名} | {关键词} | | | |
| FP-002 {功能点名} | | | | |

## 3.1 其他涉及范围（Other Impacted Areas）

> 主链路（F/E / API / B/E）之外的波及面检查。逐项确认；
> 「是否涉及」只取三个值：N/A / 涉及 / 待确认。
> 涉及项必须注明关联 FP 编号；需要跟进的转 Open Item（OI#n）。

| 检查项 | 是否涉及 | 说明 |
|---|---|---|
| Notifications（SMS / Email / Push） | {N/A / 涉及 / 待确认} | {说明，涉及注明 FP#} |
| Staff Channels（Call Centre / Branch） | | |
| Third-party Services（须查白名单） | | |
| Data Downstream（MIS / 监管报送） | | |

## 4. Out of Scope & Open Items

**Out of Scope**：endpoint 契约设计、component 选型、B/E 内部实现、{本需求特有排除项}

| # | Open Item | 关联 FP | Owner | 影响 / 是否 blocker |
|---|---|---|---|---|
| 1 | {待确认事项} | FP{n} | {BA/PO/TL/B-E} | {影响范围} |
