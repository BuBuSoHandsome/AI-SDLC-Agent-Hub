# 全局后端系统版图

Grill 环节「调到哪个服务」从这里查；solution design 的下游依赖（SAPI 名）以此为准。

## 维护规则
- 各 team 只维护自己 own 的系统行（增改 SAPI、更新职责）
- 新增任何后端系统（尤其新 b/e），必须在本表添加新行并标 owner team
- 行内容冲突时，以 owner team 维护的内容为准

## 系统清单

| 系统 | 职责 | SAPI 清单 | owner team |
|---|---|---|---|
| omnibase | {} | {} | {} |
| {待补充} | | | |
