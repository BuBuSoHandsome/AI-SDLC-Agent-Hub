# Team 接入说明

新 team 接入本 skill，在本目录下新建 {team-name}/ 文件夹，放三份文件：

## scope.md（业务范围，路由依据）
- 负责的业务域：本 team own 哪些业务（可多域，如 CAL = card + loan）
- 路由关键词：需求中出现这些词时路由到本 team
- 边界说明：与其他 team 交界处的归属（防止双不管/两边抢）

## grill-questions.md（特有追问，team 自治）
- 只放本 team 特有的问题；通用问题在 common/grill-questions.md
- 晋升规则：某问题若在第二个 team 也出现 → 上收 common，从各 team 文件删除

## system-map.md（系统版图）
- 本 team 常打交道的后端系统、SAPI 清单、各自职责
- Grill 时「调到哪个服务」从这里查

冲突优先级：公司标准（standards/solution.md）> team 配置 > skill 默认。
拆解方法论全 team 统一（见 SKILL.md），team 差异只体现在 grill 问题与系统版图。
