# CAL Team 特有追问（Card + Loan）（待填写）

只放本 team 特有的问题；通用问题在 common/grill-questions.md。
若某问题在第二个 team 也出现，上收 common。
