# CAL Team 常用系统（索引）

事实以全局版图为准：../../system-map.md
本文件只列本 team 常打交道的系统指针，不复制内容。

- omnibase：额度判定、counter offer SAPI（详见全局版图）
- {卡核心}：卡状态、账单（详见全局版图）
