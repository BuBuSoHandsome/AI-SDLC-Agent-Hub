# CAL Team 业务范围

## 负责的业务域
- 信用卡（Card）：额度（CLI）、账单、积分、分期、卡产品
- 贷款（Loan）：个人贷款、还款计划

## 路由关键词
credit card, CLI, 额度, 调额, 账单, 积分, 分期, 卡激活, loan, 贷款, 还款计划

## 边界说明
- 刷卡交易清算属 payment team
- 还款的资金扣划与 payment 共建，本 team 负责账单/额度侧
