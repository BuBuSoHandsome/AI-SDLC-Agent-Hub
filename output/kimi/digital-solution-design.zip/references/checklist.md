# Solution Design 自查清单（兜底）

Grill 环节是主力，本清单是兜底。产出后逐项核对。

## 前置
- [ ] 已阅读 references/standards/solution.md，产出与其无冲突（冲突已记入 Open Items）
- [ ] 涉及改动的 party（Mobile/AEM/API）对应的 references/guidelines/ 已加载，默认检查已逐项过

## 边界与形态
- [ ] 产出为三段式：E2E Diagram / Party 职责与边界 / Out of Scope & Open Items
- [ ] 全文无 endpoint/URL/方法/错误码表/component 选型
- [ ] 没有为后端内部实现做设计（下游只到 SAPI 名）
- [ ] E2E 图：party 齐全、调用关系正确、新增 party 已高亮、≤8 个节点
- [ ] 每个 party 都写了「边界：不做什么」

## 内容
- [ ] Mobile/AEM：改动到页面级，每页所需数据可追溯到 API 能力
- [ ] API：能力到「数据 + 同步/异步 + 失败语义」；查询类标时效、提交类标重复提交语义、通知类标送达兜底
- [ ] 下游服务：每个都标了 复用/改造/新增 + 状态
- [ ] 涉及第三方（非银行内服务）的都检查了白名单
- [ ] 涉及合规的 party 都写了合规检查项（强认证/留痕/脱敏）

## 收尾
- [ ] Grill 未获答案的问题全部进了 §3 Open Items
- [ ] 明确不做的范围已列入 §3 Out of Scope
- [ ] 增量更新时：版本号 +1、状态重置 Draft、变更记录已追加
