---
name: logic-flow-diagram
description: 将接口文档中的 logic flow（Entry & Routing / Parameter Validation / 下游调用 / 业务处理 / Response Assembly 等子小节）转换为三列模块图（common component ｜ logic flow ｜ error handling），输出 HTML。当用户提供 logic flow 文档（Markdown 文本或屏幕截图照片），要求生成架构图、分层图、模块图、三列图，或把 logic flow 落到类设计并图形化时使用。也适用于在已有图上按反馈迭代调整（改类名、加常量框、加配置文件框等）。
---

# Logic Flow 三列模块图

将 logic flow 文档转换为三列模块图：左列 common component（common jar 能力 / 常量类 / 配置文件），中列 logic flow（logic flow 每个子小节一个本服务类），右列 error handling（中止流程）。

## 两种模式

- **0→1 全新生成**：用户明确说明是从零开始，logic flow 为全量。
- **delta 增量改动**：用户明确说明是增量改动，除增量 logic flow 外，还需提供：① 本地代码库路径；② 上一次生成的 diagram HTML（spec JSON 内嵌于其中，直接提取 `<!--SPEC:...-->` 注释 base64 解码即可，不要解析 DOM）。

两种模式都要扫描用户指定的代码库（深度不同，见第 2 步）。

## 工作流（0→1 全新生成）

1. **获取并定位 logic flow 章节**。logic flow 通常只是用户传入 Markdown 文档的一部分：先在文档中定位 `Logic flow` 标题（章节号不限，可能是 `## 4. Logic flow` 也可能是其他编号），只处理该标题下的子小节。用户给屏幕截图照片则先自行读图转录原文（不要调 OCR 工具）。
1.5. **轻量扫描代码库**（用户指定的本地项目路径）：了解包结构与命名风格；查找是否已有可复用的 Constants 类 / 常量（如证件类型常量）、common jar 组件的现有用法。已有可复用件则引用而非新建。
2. **阅读 [references/column-rules.md](../references/column-rules.md)**，按语义把 logic flow 的每个子小节映射到三列。注意：标题命名是自由的，按正文语义判定，不要按标题硬匹配；业务总管类命名不得绑定当前规则。
3. **【强制确认闸】输出三列映射表，等待用户确认后才继续**。用 ask_user 或直接表格形式给出完整方案，一次性确认三列全部内容：

| 子小节（保留文档原始编号） | 归属列 | 生成类 / 框 | 分支与箭头 |
|---|---|---|---|
| 每个小节一行 | logic flow / common component / error handling | 类名、UML 框、常量框、配置文件框 | 谁指向谁、触发条件 |

类名采用**提案制**：按命名约定先给一版，用户直接改不认同的。用户提出修改后按修改执行，**不再二次确认**。

确认表中每条 common component / error handling 条目必须带**依据来源标注**；delta 模式下确认表再加一列「变化」（新增 / 修改 / 不变），用户重点审新增和修改行：
- 「文档明确」：logic flow 原文直接写明（如"调用公共服务组件提供的 xxx 能力"）
- 「推断」：按惯例或上下文推断（如"脱敏"推断为 common jar 能力；"调下游系统"推断需要 client 类）
- 「待确认」：文档未覆盖的设计决策——组件归属（common jar 还是本服务实现）、是否抽常量及常量值、配置文件的文件名与存放路径（新建还是复用已有文件）

「推断」和「待确认」项必须在表中用 ⚠️ 标出，确认时用户重点审这些条目。
4. **编写 spec JSON**（格式见 `scripts/render_diagram.js` 顶部注释）。logic flow 每个子小节一个 step：logic 必填；`tag` 填文档中的原始编号与标题（如 "5.3 Call Backend CUS"），保证图与文档对得上号；有外部依赖加 `cc`（可多个框）；有中止分支加 `err`。logic 的 `style`：普通类 blue，ResponseBuilder purple，透传/说明类 grey。bullets 中可用 `<span class="hl">...</span>` 高亮 common component 引用。注意保持每行文字简短，过长会溢出框体，宁可拆成两条 bullet。
5. **渲染**（Node.js）：

```bash
node scripts/render_diagram.js spec.json --template assets/diagram-template.html --out /mnt/agents/output/{名称}_三列模块图
```

产出 `{名称}_三列模块图.html`，即最终交付物。

## 工作流（delta 增量改动）

1. 读取用户提供的上一次 diagram HTML，提取 `<!--SPEC:...-->` 注释并 base64 解码，得到旧 spec。
2. **深度扫描代码库**（用户指定路径）：找到该 endpoint 现有类，类名以对齐现有代码为准；校验增量中提到的类/常量是否已存在——已存在且可复用则不新建，在确认表中标注"复用现有"。
3. 按增量 logic flow 修改旧 spec：改动的 logic 框加 `"delta": true`；随后走与 0→1 相同的确认闸（映射表带「变化」列）、渲染、交付。

## 迭代修改（已有图）

用户对已有图做局部调整（改类名、改文案、加框、删框）时，**不走确认闸**：从 HTML 提取 spec，改对应字段重新渲染，不要手改 HTML 结构。

## 注意事项

- 文档中"无参数校验"的小节仍要生成 `{Endpoint}ParameterValidator` 标准件类（return true），保持每个 endpoint 结构统一。
- "中止流程，返回 2.2.x"的小节整体放 error handling 列，由触发它的 logic 步骤箭头指向并标注触发条件。
- 图标题用接口路径（如 `GET /loans/debt-consolidation`），不带 query 参数。
- spec JSON 不单独交付：它以 base64 注释形式内嵌在 HTML 里（`<!--SPEC:...-->`），用户只存 HTML 即可，delta 场景从 HTML 回读。
